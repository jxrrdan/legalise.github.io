/* eslint-disable no-unused-vars */
const { version } = require('../package.json');
const VERSION_RANGE = (module.exports.VERSION_RANGE = version);
const UNPKG_CDN_URL = (module.exports.UNPKG_CDN_URL = `https://unpkg.com/@popperjs/core@2`);
