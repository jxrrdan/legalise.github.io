<!DOCTYPE html>
<html>
  <head>	<title>Whatcode? | Portal Settings</title>
      <script src="https://whatcode.dougbros.co.uk/pace.js"></script>
  <link rel="stylesheet" href="https://whatcode.dougbros.co.uk/pace.css">
          <!-- <meta http-equiv="Refresh" content="0; url=//https://whatcode.dougbros.co.uk/app" />-->
     </head>
     <body>
Redirecting you...
       <script language="javascript">
    window.location.href = "https://whatcode.dougbros.co.uk/app"
</script>
      </body>
</html>